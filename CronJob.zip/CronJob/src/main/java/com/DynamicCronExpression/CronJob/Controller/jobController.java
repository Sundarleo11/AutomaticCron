package com.DynamicCronExpression.CronJob.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.DynamicCronExpression.CronJob.Service.jobService;
import com.DynamicCronExpression.CronJob.model.job;

@RestController
public class jobController {
	
	
	  @Autowired 
	  public jobService jobServiceinfo;
	  
	  @PostMapping("/OpenrReport") public job addnewjob(@RequestBody job jobinfo) {
	  return jobServiceinfo.addjob(jobinfo);
	  
	  }
	 

}
