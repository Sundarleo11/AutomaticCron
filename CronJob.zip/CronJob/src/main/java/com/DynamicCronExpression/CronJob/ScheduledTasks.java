package com.DynamicCronExpression.CronJob;

import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.DynamicCronExpression.CronJob.model.job;
import com.DynamicCronExpression.CronJob.repo.jobRepo;

@Component
public class ScheduledTasks {

	@Autowired
	public jobRepo jobinforepo;

	// Check every minute
	@Scheduled(fixedDelay = 60000)
	public void scheduleTask() throws Exception {

		List<job> cronExpression = fetchCronExpressionFromDB();

		for (job job : cronExpression) {

			SimpleDateFormat formatTime = new SimpleDateFormat("H:mm");
			String localtime = formatTime.format(new Date());

			String dbtime = formatTime.format(job.getJobstarttime());

			// Compare DB Time with LocalTimeZone time
			if (localtime.equals(dbtime)) {
				System.out.println("inside if" + localtime);

				// Extract the hour and minute from the DB expression
				String[] cronParts = dbtime.split(":");
				System.out.println("cron part" + cronParts);
				String hour = cronParts[0];
				String minute = cronParts[1];

				// Get the current time
				LocalTime currentTime = LocalTime.now();

				// If the stored time matches the current time, call the stored procedure
				if (currentTime.getHour() == Integer.parseInt(hour)
						&& currentTime.getMinute() == Integer.parseInt(minute)) {
					//call on 46seconde
					System.out.println("CALL your_stored_procedure_name()");

				}
			}

		}
	}

	private List<job> fetchCronExpressionFromDB() throws Exception {
		// Fetch the date from the database
		List<job> timelist = jobinforepo.findAllById(6);
		return timelist;
	}

}
