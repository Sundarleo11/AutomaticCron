package com.DynamicCronExpression.CronJob.Service;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.batch.BatchProperties.Job;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.scheduling.support.CronSequenceGenerator;
import org.springframework.stereotype.Service;

import com.DynamicCronExpression.CronJob.model.job;
import com.DynamicCronExpression.CronJob.repo.jobRepo;
import com.cronutils.model.definition.CronDefinition;
import com.cronutils.model.definition.CronDefinitionBuilder;
import com.cronutils.parser.CronParser;
import com.cronutils.model.CronType;
@Service
public class CronExpressionGenerator {
	

	@Autowired
	public jobRepo jobinforepo;
	

	
	  @Scheduled(fixedDelay = 60000) // Check every minute
	public String generateCronExpression() throws ParseException  {
		DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("hh:mm:ss");
        String localTimeString = FOMATTER.format(LocalTime.now());
        Optional<job> timelist=jobinforepo.findById(1);
      
      if(timelist.isPresent()) {
    	   job j=timelist.get(); 
    	    LocalTime time= LocalTime.parse(localTimeString, DateTimeFormatter.ofPattern("H:mm:ss"));
    	    if(time.equals(j.getJobstarttime())) {
    	    	System.out.println(time);
    	    	System.out.println(j.getJobstarttime());
    		   String spliTime[]=localTimeString.split(":");
         	   String h=spliTime[0];
         	   String m=spliTime[1];
         	  return String.format("%s %s %s %s %s %s", "*", m, h, "*", "*","*");
          }	  
    	      
       }
   
       //Never run job 
       return "* * * 31 2 *";    
		
    }
	
	
	
	
	
}
