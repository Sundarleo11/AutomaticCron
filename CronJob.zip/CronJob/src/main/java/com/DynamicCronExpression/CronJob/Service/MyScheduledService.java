package com.DynamicCronExpression.CronJob.Service;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.DynamicCronExpression.CronJob.model.job;
import com.DynamicCronExpression.CronJob.repo.jobRepo;

@Service
public class MyScheduledService {

	

	
	@Scheduled(cron = "#{@cronExpressionGenerator.generateCronExpression()}")
	public void scheduledTask() {		
		System.out.println("Scheduled task executed at the dynamically generated time.");
	}


	
	
	

}
