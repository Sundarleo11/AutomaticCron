package com.DynamicCronExpression.CronJob.Service;

import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.DynamicCronExpression.CronJob.model.job;
import com.DynamicCronExpression.CronJob.repo.jobRepo;

@Service
public class jobService {

	@Autowired
	public jobRepo jobinforepo;

	//public CronExpressionGenerator cronExpressionGenerator;
	
	public job addjob(job jobinfo) {
		// TODO Auto-generated method stub
		
		return jobinforepo.save(jobinfo);
	}
	
	
    
  
}
