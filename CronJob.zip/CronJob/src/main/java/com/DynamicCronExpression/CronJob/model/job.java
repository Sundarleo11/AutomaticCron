package com.DynamicCronExpression.CronJob.model;






import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name="job")
public class job {

	
	
	private int id;
	
	@Id
	private int jobid;
 

	private Time jobstarttime;

	@Override
	public String toString() {
		return "job [id=" + id + ", jobstarttime=" + jobstarttime + "]";
	}




	


	
}
