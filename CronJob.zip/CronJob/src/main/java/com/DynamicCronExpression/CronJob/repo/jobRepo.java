package com.DynamicCronExpression.CronJob.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.DynamicCronExpression.CronJob.model.job;
@Repository
public interface jobRepo extends JpaRepository<job, Integer> {
	
	 job findByjobstarttime(int id);

	

	List<job> findByjobid(int id);



	List<job> findAllById(int i);

	

}
