package com.DynamicCronExpression.CronJob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CronJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
